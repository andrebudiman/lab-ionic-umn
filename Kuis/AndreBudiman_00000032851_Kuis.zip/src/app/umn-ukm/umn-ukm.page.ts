import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-umn-ukm',
  templateUrl: './umn-ukm.page.html',
  styleUrls: ['./umn-ukm.page.scss'],
})
export class UmnUkmPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
