export class Ukm{
    constructor(
        public id: string,
        public name: string,
        public description: string
    ){}
}